import random
from art import logo, vs
from game_data import data
from replit import clear


#get the values of key inside choice dictionary
def format_account(account):
  """Format account into printable format: name, description and country"""
  name = account['name']
  description = account['description']
  country = account['country']
  return f"{name}, a {description}, from {country}"

#print logo
print(logo)

game_should_continue = True
current_score = 0
account_b = random.choice(data)

while game_should_continue:

  #generate random choice from data_list
  account_a = account_b
  account_b = random.choice(data)
  
  if account_a == account_b:
    account_b = random.choice(data)


  print(f'compare A: {format_account(account_a)})')

  print(vs)

  print(f'Against B: {format_account(account_b)})')

  guess = (input("Who has more followers? Type 'A' or 'B': ")).lower()
  a_follower = account_a['follower_count']
  b_follower = account_b['follower_count']

  #clear screen before rounds
  clear()

  print(logo)

  if guess == 'a' and a_follower > b_follower:
    current_score += 1
    print(f"You're right! Current score: {current_score}.")
  elif guess == 'b' and a_follower < b_follower:
    current_score += 1
    print(f"You're right! Current score: {current_score}.")
  elif guess != 'a' and guess != 'b':
    print("Invalid input!")
    print(f"You're right! Current score: {current_score}.")
  else:
    game_should_continue = False
    print(f"Sorry, you're wrong! final score: {current_score}.")